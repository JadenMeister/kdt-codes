console.log("안녕 스크립트");
