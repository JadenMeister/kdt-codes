const http = require("http");
const fs = require("fs");
const querystring = require("querystring");

const server = http.createServer(function (req, res) {
  if (req.method === "GET") {
    if (req.url === "/") {
      const MAIN_PAGE = fs.readFileSync("nohello.html", "utf-8");
      res.setHeader("Content-Type", "text/html; utf-8;");
      res.end(MAIN_PAGE);
    }

    if (req.url === "/nohello") {
      const nohello = fs.readFileSync("nohello.html", "utf-8");
      res.end(nohello);
    }
    if (req.url === "/nohello.css") {
      const marketList = fs.readFileSync("nohello.css", "utf-8");
      res.setHeader("Content-Type", "text/css", "charset=utf-8");
      res.end(marketList);
    }
  } else if (req.method === "POST") {
    if (req.url === "/created_list") {
      res.on("data", function (data) {
        console.log(data.toString());
        let list = querystring.parse(data.toString());
        res.writeHead(200, { "Content-Type": "text/html" });

        res.end(
          "name:" +
            list.name +
            "price:" +
            list.price +
            "quantity:" +
            list.quantity
        );
      });
    }
  }
});

let PORT = 3003;

server.listen(PORT, function () {
  console.log(`http://localhost:${PORT} 에서 서버 도는 중`);
});
